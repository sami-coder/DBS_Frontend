/*Name : Sumit Kawale
ID : 801135233
* */
package com.example.inclass10movie;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
public class MainActivity extends AppCompatActivity {

    Button AddMovie ;
    Button Edit;
    Button DeleteMovie;
    Button ShowListByYear;
    Button ShowListByRating;

    ArrayList<movieDomain> movieDomainslist,movieDomainsdel,moviecreatelist,arrayrating,arrayyear;
    String[] moviesToedit,moviesTodel;
    movieDomain movie,movieId;


    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("My Favorite Movies");
        setContentView(R.layout.activity_main);
        AddMovie = findViewById(R.id.AddMovie);
        Edit = findViewById(R.id.EditMovie);
        DeleteMovie = findViewById(R.id.DeleteMovie);
        ShowListByYear = findViewById(R.id.ShowMovieListByYear);
        ShowListByRating = findViewById(R.id.ShowMovieListByRating);
        moviecreatelist=new ArrayList<>();



        AddMovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,addMovie.class);
                startActivity(intent);
            }
        });

        Edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                movieDomainslist = new ArrayList<>();

                db.collection("Movies")
                        .get()
                        .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                if (task.isSuccessful()) {
                                    for (QueryDocumentSnapshot document : task.getResult()) {
                                        Log.i("db", document.getId() + " => " + document.getData());

                                        movie = new movieDomain(document.getData());
                                        movie.setId(document.getId());
                                        System.out.println(document.getData());
                                        movieDomainslist.add(movie);

                                    }
                                    System.out.println(movieDomainslist);
                                    androidx.appcompat.app.AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                    builder.setTitle("Pick a Movie");
                                    moviesToedit = new String[movieDomainslist.size()];

                                    for (int k = 0; k < movieDomainslist.size(); k++) {

                                        moviesToedit[k] = movieDomainslist.get(k).getName();
                                    }
                                    if(movieDomainslist.isEmpty()){
                                        Toast.makeText(MainActivity.this, "Add movies to edit", Toast.LENGTH_SHORT).show();
                                    }else {
                                        builder.setItems(moviesToedit, new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialogInterface, int i) {
                                                Intent intent = new Intent(MainActivity.this, editMovie.class);
                                                intent.putExtra("data", movieDomainslist.get(i));

                                                intent.putExtra("id", movieDomainslist.get(i).getId());
                                                startActivity(intent);
//

                                            }
                                        });

                                        builder.show();
                                    }

                                } else {
                                    Log.i("db", "Error getting documents.", task.getException());
                                }
                            }
                        });


            }

        });

        ShowListByYear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                arrayyear=new ArrayList<>();
                db.collection("Movies")
                        .get()
                        .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                if (task.isSuccessful()) {
                                    for (QueryDocumentSnapshot document : task.getResult()) {
                                        Log.i("db", document.getId() + " => " + document.getData());

                                        movie = new movieDomain(document.getData());

                                        arrayyear.add(movie);

                                    }
                                    if(arrayyear.isEmpty()) {
                                        Toast.makeText(MainActivity.this, "Add the movies", Toast.LENGTH_SHORT).show();
                                    }else {
                                        Intent intent = new Intent(MainActivity.this, showMovieListByYear.class);
                                        startActivity(intent);
                                    }
//

                                } else {
                                    Log.i("db", "Error getting documents.", task.getException());
                                }
                            }
                        });

            }
        });

        ShowListByRating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                arrayrating=new ArrayList<>();

                db.collection("Movies")
                        .get()
                        .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                if (task.isSuccessful()) {
                                    for (QueryDocumentSnapshot document : task.getResult()) {
                                        Log.i("db", document.getId() + " => " + document.getData());

                                        movie = new movieDomain(document.getData());

                                        arrayrating.add(movie);

                                    }
                                    if(arrayrating.isEmpty()){
                                        Toast.makeText(MainActivity.this, "Please add movies!!!!!", Toast.LENGTH_SHORT).show();
                                    }else {
                                        Intent intent = new Intent(MainActivity.this, showMovieListByRating.class);
                                        startActivity(intent);
                                    }
//

                                } else {
                                    Log.i("db", "Error getting documents.", task.getException());
                                }
                            }
                        });

            }
        });

        DeleteMovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                movieDomainsdel=new ArrayList<>();
                db.collection("Movies")
                        .get()
                        .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                if (task.isSuccessful()) {
                                    for (QueryDocumentSnapshot document : task.getResult()) {
                                        Log.i("db", document.getId() + " => " + document.getData());

                                        movie = new movieDomain(document.getData());
                                        movie.setId(document.getId());

                                        movieDomainsdel.add(movie);

                                    }

                                    androidx.appcompat.app.AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                    builder.setTitle("Pick a Movie");
                                    moviesTodel = new String[movieDomainsdel.size()];

                                    for (int k = 0; k < movieDomainsdel.size(); k++) {

                                        moviesTodel[k] = movieDomainsdel.get(k).getName();
                                    }
                                    if(movieDomainsdel.isEmpty()){
                                        Toast.makeText(MainActivity.this, "Add  movies to delete!!!!!", Toast.LENGTH_SHORT).show();
                                    }else {
                                        builder.setItems(moviesTodel, new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialogInterface, int i) {
                                                db.collection("Movies").document(movieDomainsdel.get(i).getId())
                                                        .delete()
                                                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                            @Override
                                                            public void onSuccess(Void aVoid) {
                                                                Log.d("asf", "DocumentSnapshot successfully deleted!");
                                                                Toast.makeText(MainActivity.this, "Movie Deleted successfully", Toast.LENGTH_SHORT).show();
                                                            }
                                                        })
                                                        .addOnFailureListener(new OnFailureListener() {
                                                            @Override
                                                            public void onFailure(@NonNull Exception e) {
                                                                Log.w("sd", "Error deleting document", e);
                                                            }
                                                        });
                                            }


                                        });

                                        builder.show();
                                    }

                                } else {
                                    Log.i("db", "Error getting documents.", task.getException());
                                }
                            }
                        });


            }
        });
    }
}
