package com.example.inclass10movie;

import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;

public class movieDomain implements Serializable {

    String name;
    String description;
    String genre;
    int year;
    int rating;
    URL imdb;
    String id="";

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public movieDomain(String name, String description, String genre, Integer year, Integer rating, URL imdb) {
        this.name = name;
        this.description = description;
        this.genre = genre;
        this.year = year;
        this.rating = rating;
        this.imdb = imdb;
    }

    public movieDomain(Map movieMap){

        this.name=(String)movieMap.get("name");
        this.description=(String) movieMap.get("description");
        this.genre=(String)movieMap.get("genre");
        this.year=(int)(long)movieMap.get("year");
        this.rating=(int)(long)movieMap.get("rating");
        URL url=null;
        try {
            url=new URL((String)movieMap.get("imdb"));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        this.imdb=url;
        this.id=(String)movieMap.get("id");

    }

//    protected MovieDomain(Parcel in) {
//        name = in.readString();
//        description = in.readString();
//        genre = in.readString();
//        if (in.readByte() == 0) {
//            year = null;
//        } else {
//            year = in.readInt();
//        }
//        if (in.readByte() == 0) {
//            rating = null;
//        } else {
//            rating = in.readInt();
//        }
//    }


    public movieDomain(Object imdb, Object year, Object genre, Object name, Object rating, Object description) {
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public String getImdb() {
        return imdb.toString();
    }

    public void setImdb(URL imdb) {
        this.imdb = imdb;
    }

    @Override
    public String toString() {
        return "MovieDomain{" +
                "name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", genre='" + genre + '\'' +
                ", year=" + year +
                ", rating=" + rating +
                ", imdb=" + imdb +
                '}';
    }


    public movieDomain() {
    }


}
