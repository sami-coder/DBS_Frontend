package com.example.inclass10movie;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.firestore.FirebaseFirestore;

import java.net.URL;
import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

import android.content.Intent;
import android.os.Build;

import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;

import java.net.MalformedURLException;

public class editMovie extends AppCompatActivity {

    String name = "";
    String description ="";
    String genre="";
    Integer year=0;

    URL imdb;

    Button saveChanges;
    EditText movienametext,movieYeartext,imdbtext,descriptionText;
    SeekBar ratingSeekbar;
    Spinner genreScrollDownspinner;
    String selectedGenre;
    TextView ratingTextView;
    private String movieName,movieDesc,movieImdb;
    private Integer movieYear;
    int movieRating;
    movieDomain movieDomain;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_movie);

        final ArrayList<String> movieGenereList=new ArrayList<String>();
        movieGenereList.add("Select");
        movieGenereList.add(("Action"));
        movieGenereList.add("Animation");
        movieGenereList.add("Comedy");
        movieGenereList.add("Documentry");
        movieGenereList.add("Family");
        movieGenereList.add("Horror");
        movieGenereList.add("Crime");
        movieGenereList.add("Others");

        final FirebaseFirestore db = FirebaseFirestore.getInstance();
        final Intent intent=getIntent();


        saveChanges=findViewById(R.id.addmoviebutton);
        ratingTextView=findViewById(R.id.ratingTextview);
        movienametext=findViewById(R.id.edittextmoviename);
        movieYeartext=findViewById(R.id.yearedittext);
        imdbtext=findViewById(R.id.edittextimdburl);
        descriptionText=findViewById(R.id.descriptioneditText);
        ratingSeekbar=findViewById(R.id.ratingseekBar);
        genreScrollDownspinner=findViewById(R.id.generescrolldown);

        ratingSeekbar.setMin(1);
        ratingSeekbar.setMax(5);
        movieDomain = (movieDomain) intent.getExtras().getSerializable("data");
        final String movieId=intent.getExtras().getString("id");
        System.out.println(movieId);
        movienametext.setText(movieDomain.getName());
        descriptionText.setText(movieDomain.getDescription());

        ratingSeekbar.setProgress(movieDomain.getRating());
        ratingTextView.setText(String.valueOf(movieDomain.getRating())+"/5");
        movieYeartext.setText(String.valueOf(movieDomain.getYear()));
        imdbtext.setText(String.valueOf(movieDomain.getImdb()));


        ratingSeekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                movieRating=i;
                ratingTextView.setText(String.valueOf(movieRating));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        ArrayAdapter<String> arrayAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,movieGenereList);
        genreScrollDownspinner.setAdapter(arrayAdapter);

        genreScrollDownspinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                selectedGenre=adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        switch (movieDomain.genre) {
            case "Select":
                genreScrollDownspinner.setSelection(0);
                break;
            case "Action":
                genreScrollDownspinner.setSelection(1);
                break;
            case "Animation":
                genreScrollDownspinner.setSelection(2);
                break;
            case "Comedy":
                genreScrollDownspinner.setSelection(3);
                break;
            case "Documentary":
                genreScrollDownspinner.setSelection(4);
                break;
            case "Family":
                genreScrollDownspinner.setSelection(5);
                break;
            case "Horror":
                genreScrollDownspinner.setSelection(6);
                break;
            case "Crime":
                genreScrollDownspinner.setSelection(7);
                break;
            case "Others":
                genreScrollDownspinner.setSelection(8);
                break;

        }

        saveChanges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (movienametext.getText().toString().length() == 0){
                    movienametext.setError("Please Enter Name");
                }
                else{name = movienametext.getText().toString();}


                if (descriptionText.getText().toString().length() == 0){
                    descriptionText.setError("Please Enter Description");
                }else{description = descriptionText.getText().toString();}



                if(movieYeartext.getText().toString().length() != 4){
                    movieYeartext.setError("Please enter valid year");
                }else{ year = Integer.parseInt(movieYeartext.getText().toString());}

                if(Patterns.WEB_URL.matcher(imdbtext.getText()).matches()){
                    try {
                        imdb = new URL(imdbtext.getText().toString());
                    } catch (MalformedURLException e) {
                        imdbtext.setError("please enter valid URL");
                        e.printStackTrace();
                    }
                }else {
                    imdbtext.setError("please enter valid URL");
                }

                if (genreScrollDownspinner.getSelectedItem().toString().equals("Select")){
                    Toast.makeText(editMovie.this, "Please select at least one Genre", Toast.LENGTH_SHORT).show();
                }else{genre = genreScrollDownspinner.getSelectedItem().toString();}



                if (!name.equals("") && !description.equals("")  && !genre.equals("Select") && year != 0 && imdb!=null){
                    final movieDomain movieDomain = new movieDomain(name,description,genre,year,movieRating,imdb);




                    db.collection("Movies").document(movieId)
                            .set(movieDomain)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Log.i("success", "DocumentSnapshot successfully written!");
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.w("faioe", "Error writing document", e);
                                }
                            });

                    finish();

                }
            }
        });

    }
}
