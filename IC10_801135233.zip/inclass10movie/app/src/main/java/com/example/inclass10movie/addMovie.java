package com.example.inclass10movie;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class addMovie extends AppCompatActivity {


    String name = "";
    String description ="";
    String genre="";
    Integer year=0;

    URL imdb;

    Button addmoviebutton;
    EditText movienametext,movieYeartext,imdbtext,descriptionText;
    SeekBar ratingSeekbar;
    Spinner genreScrollDownspinner;
    String selectedGenre;
    TextView ratingTextView;
    private String movieName,movieDesc,movieImdb;
    private Integer movieYear;
    int movieRating;

    public ArrayList<movieDomain> movieDomainArrayList = new ArrayList<>();

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_movie);

        final Intent intent =getIntent();

        final ArrayList<String> movieGenereList=new ArrayList<String>();
        movieGenereList.add("Select");
        movieGenereList.add(("Action"));
        movieGenereList.add("Animation");
        movieGenereList.add("Comedy");
        movieGenereList.add("Documentry");
        movieGenereList.add("Family");
        movieGenereList.add("Horror");
        movieGenereList.add("Crime");
        movieGenereList.add("Others");

        final FirebaseFirestore db = FirebaseFirestore.getInstance();


        addmoviebutton=findViewById(R.id.addmoviebutton);
        ratingTextView=findViewById(R.id.ratingTextview);
        movienametext=findViewById(R.id.edittextmoviename);
        movieYeartext=findViewById(R.id.yearedittext);
        imdbtext=findViewById(R.id.edittextimdburl);
        descriptionText=findViewById(R.id.descriptioneditText);
        ratingSeekbar=findViewById(R.id.ratingseekBar);
        genreScrollDownspinner=findViewById(R.id.generescrolldown);

        ArrayAdapter<String> arrayAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,movieGenereList);
        genreScrollDownspinner.setAdapter(arrayAdapter);

        ratingSeekbar.setMin(0);
        ratingSeekbar.setMax(5);
        ratingSeekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                movieRating=i;
                ratingTextView.setText(String.valueOf(movieRating));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        addmoviebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (movienametext.getText().toString().length() == 0){
                    movienametext.setError("Please Enter Name");
                }
                else{name = movienametext.getText().toString();}


                if (descriptionText.getText().toString().length() == 0){
                    descriptionText.setError("Please Enter Description");
                }else{description = descriptionText.getText().toString();}



                if(movieYeartext.getText().toString().length() != 4){
                    movieYeartext.setError("Please enter valid year");
                }else{ year = Integer.parseInt(movieYeartext.getText().toString());}

                if(Patterns.WEB_URL.matcher(imdbtext.getText()).matches()){
                    try {
                        imdb = new URL(imdbtext.getText().toString());
                    } catch (MalformedURLException e) {
                        imdbtext.setError("please enter valid URL");
                        e.printStackTrace();
                    }
                }else {
                    imdbtext.setError("please enter valid URL");
                }

                if (genreScrollDownspinner.getSelectedItem().toString().equals("Select")){
                    Toast.makeText(addMovie.this, "Please select at least one Genre", Toast.LENGTH_SHORT).show();
                }else{genre = genreScrollDownspinner.getSelectedItem().toString();}



                if (!name.equals("") && !description.equals("")  && !genre.equals("Select") && year != 0 && imdb!=null){
                    final movieDomain movieDomain = new movieDomain(name,description,genre,year,movieRating,imdb);


                    Map<String, movieDomain> movie = new HashMap<>();
                    movie.put(movieDomain.getName(),movieDomain);

                    db.collection("Movies")
                            .add(movieDomain)
                            .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                @Override
                                public void onSuccess(DocumentReference documentReference) {
                                    Log.i("doc", "DocumentSnapshot added with ID: " + documentReference.getId());
                                    finish();
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.i("doc", "Error adding document", e);
                                }
                            });



                }
            }
        });


    }
}
