package com.example.inclass10movie;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class showMovieListByRating extends AppCompatActivity {


    TextView TitleValue ;
    TextView Description ;
    TextView GenreValue ;
    TextView RatingValue ;
    TextView YearValue ;
    TextView IMDBValue;
    ImageView First;
    ImageView Previous;
    ImageView next;
    ImageView last;

    Button finish;

    TextView Title;

    ArrayList<movieDomain> moviesbyYr=new ArrayList<>();



    int i=0;

    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_movie_list_by_rating);

        TitleValue = findViewById(R.id.TitleValue);
        Description = findViewById(R.id.Description);
        GenreValue = findViewById(R.id.GenreValue);
        RatingValue = findViewById(R.id.RatingValue);
        YearValue = findViewById(R.id.YearValue);
        IMDBValue = findViewById(R.id.IMDBValue);
        First = findViewById(R.id.First);
        Previous = findViewById(R.id.Previous);
        next = findViewById(R.id.next);
        last = findViewById(R.id.last);
        Title = findViewById(R.id.Title);
        Description.setEnabled(false);
        finish = findViewById(R.id.finish);

        db.collection("Movies")
                .orderBy("rating", Query.Direction.DESCENDING)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d("db", document.getId() + " => " + document.getData());
                                // System.out.println(document.getData());
                                movieDomain movieDomain=new movieDomain(document.getData());
                                moviesbyYr.add(movieDomain);

                            }

                            TitleValue.setText(moviesbyYr.get(i).getName());
                            Description.setText(moviesbyYr.get(i).getDescription());
                            GenreValue.setText(String.valueOf(moviesbyYr.get(i).getGenre()));
                            RatingValue.setText(String.valueOf(moviesbyYr.get(i).getRating())+"/5");
                            YearValue.setText(String.valueOf(moviesbyYr.get(i).getYear()));
                            IMDBValue.setText(moviesbyYr.get(i).getImdb());

                            final int j=moviesbyYr.size();

                            First.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    if (i == 0) {
                                        Toast.makeText(showMovieListByRating.this, "This is First Movie", Toast.LENGTH_SHORT).show();
                                    } else {
                                        i = 0;
                                        TitleValue.setText(moviesbyYr.get(i).getName());
                                        Description.setText(moviesbyYr.get(i).getDescription());
                                        GenreValue.setText(String.valueOf(moviesbyYr.get(i).getGenre()));
                                        RatingValue.setText(String.valueOf(moviesbyYr.get(i).getRating())+"/5");
                                        YearValue.setText(String.valueOf(moviesbyYr.get(i).getYear()));
                                        IMDBValue.setText(moviesbyYr.get(i).getImdb());
                                    }
                                }
                            });

                            Previous.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    if (i == 0) {
                                        Toast.makeText(showMovieListByRating.this, "This is the first movie", Toast.LENGTH_SHORT).show();
                                    } else {
                                        i--;
                                        TitleValue.setText(moviesbyYr.get(i).getName());
                                        Description.setText(moviesbyYr.get(i).getDescription());
                                        GenreValue.setText(String.valueOf(moviesbyYr.get(i).getGenre()));
                                        RatingValue.setText(String.valueOf(moviesbyYr.get(i).getRating())+"/5");
                                        YearValue.setText(String.valueOf(moviesbyYr.get(i).getYear()));
                                        IMDBValue.setText(moviesbyYr.get(i).getImdb());
                                    }
                                }
                            });

                            next.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    if (i ==j-1){
                                        Toast.makeText(showMovieListByRating.this, "This is the last movie", Toast.LENGTH_SHORT).show();
                                    }else{
                                        i++;
                                        TitleValue.setText(moviesbyYr.get(i).getName());
                                        Description.setText(moviesbyYr.get(i).getDescription());
                                        GenreValue.setText(String.valueOf(moviesbyYr.get(i).getGenre()));
                                        RatingValue.setText(String.valueOf(moviesbyYr.get(i).getRating())+"/5");
                                        YearValue.setText(String.valueOf(moviesbyYr.get(i).getYear()));
                                        IMDBValue.setText(moviesbyYr.get(i).getImdb());
                                    }
                                }
                            });

                            last.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    if(i==j-1){
                                        Toast.makeText(showMovieListByRating.this, "This is the last movie", Toast.LENGTH_SHORT).show();
                                    }else {
                                        i=j-1;
                                        TitleValue.setText(moviesbyYr.get(i).getName());
                                        Description.setText(moviesbyYr.get(i).getDescription());
                                        GenreValue.setText(String.valueOf(moviesbyYr.get(i).getGenre()));
                                        RatingValue.setText(String.valueOf(moviesbyYr.get(i).getRating())+"/5");
                                        YearValue.setText(String.valueOf(moviesbyYr.get(i).getYear()));
                                        IMDBValue.setText(moviesbyYr.get(i).getImdb());
                                    }
                                }
                            });

                            finish.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    finish();
                                }
                            });


                        } else {
                            Log.d("db", "Error getting documents: ", task.getException());
                        }
                    }
                });


    }
}
